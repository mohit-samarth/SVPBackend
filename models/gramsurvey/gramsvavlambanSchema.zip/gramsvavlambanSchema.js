import mongoose from 'mongoose';

const GramsavalambanSchema = new mongoose.Schema({
  surveyerName: { type: String, required: true },
  village: { type: String, required: true },
  grampanchayat: { type: String, required: true },
  taluka: { type: String, required: true },
  district: { type: String, required: true },
  pinCode: { type: String, required: true },
  
  primaryHealthCenter: {
    type: String,
    enum: ['Yes', 'No'],
    required: true,
  },
  primaryHealthCenterDistance: {
    type: Number,
    required: function() {
      return this.primaryHealthCenter === 'Yes';
    },
  },
  arogySevakName: {
    type: String,
    required: function() {
      return this.primaryHealthCenter === 'Yes';
    },
  },
  arogySevakContact: {
    type: String,
    required: function() {
      return this.primaryHealthCenter === 'Yes';
    },
  },
  
  policeStation: {
    type: String,
    enum: ['Yes', 'No'],
    required: true,
  },
  policeStationDistance: {
    type: Number,
    required: function() {
      return this.policeStation === 'Yes';
    },
  },
  policeAdhikariName: {
    type: String,
    required: function() {
      return this.policeStation === 'Yes';
    },
  },
  policeAdhikariContact: {
    type: String,
    required: function() {
      return this.policeStation === 'Yes';
    },
  },
  
  otherCommunityCenter: {
    type: String,
    enum: ['Yes', 'No'],
    required: true,
  },
  
  temple: {
    type: String,
    enum: ['Yes', 'No'],
    required: true,
  },
  templeName: {
    type: String,
    required: function() {
      return this.temple === 'Yes';
    },
  },
  
  otherReligiousPlace: {
    type: { type: String, enum: ['Church', 'Majjid', 'Other', 'None'] },
    specify: { 
      type: String,
      required: function() {
        return this.otherReligiousPlace === 'Other';
      }
    }
  },
  
  utsavOrMela: {
    type: String,
    enum: ['Yes', 'No'],
    required: true,
  },
  utsavOrMelaDetails: {
    type: String,
    required: function() {
      return this.utsavOrMela === 'Yes';
    },
  },
  
  roadCondition: {
    type: { type: String, enum: ['RCC', 'Asphalt', 'Row and Rough Streets', 'Other'] },
    specify: { 
      type: String,
      required: function() {
        return this.roadCondition === 'Other';
      }
    }
  },
  
  mobileNetworkCall: {
    type: String,
    enum: ['good', 'weak', 'poor', 'no signal'],
    required: true
  },
  
  mobileNetworkInternet: {
    type: String,
    enum: ['good', 'weak', 'poor', 'no signal'],
    required: true
  },
  
  goodNetworkSim: {
    type: String,
    enum: ['Airtel', 'VI', 'Jio', 'BSNL'],
    required: true
  },
  
  sarpanch: {
    name: { type: String, required: true },
    contactNo: { type: String, required: true }
  },
  
  pramukh: {
    name: { type: String, required: true },
    contactNo: { type: String, required: true }
  },
  
  mahilaBachatGat: {
    type: String,
    enum: ['Yes', 'No'],
    required: true,
  },
  mahilaBachatGatGroups: [{
    name: { 
      type: String,
      required: function() {
        return this.mahilaBachatGat === 'Yes';
      }
    },
    numberOfGroups: { 
      type: Number,
      required: function() {
        return this.mahilaBachatGat === 'Yes';
      }
    },
    sadasyaPerGroup: { 
      type: Number,
      required: function() {
        return this.mahilaBachatGat === 'Yes';
      }
    }
  }],
  
  krishiGat: {
    type: String,
    enum: ['Yes', 'No'],
    required: true,
  },
  krishiGatGroups: [{
    name: { 
      type: String,
      required: function() {
        return this.krishiGat === 'Yes';
      }
    },
    numberOfGroups: { 
      type: Number,
      required: function() {
        return this.krishiGat === 'Yes';
      }
    },
    sadasyaPerGroup: { 
      type: Number,
      required: function() {
        return this.krishiGat === 'Yes';
      }
    }
  }],
  
  primaryAgriculturalProduction: {
    type: { type: String, enum: ['Rice', 'Jowar', 'Finger Millet', 'Barnyard Millet', 'Wheat', 'Other'] },
    specify: { 
      type: String,
      required: function() {
        return this.primaryAgriculturalProduction === 'Other';
      }
    }
  },
  
  otherIncomeSource: {
    type: { type: String, enum: ['Labour', 'Goats', 'Poultry', 'Mango Tree', 'Other'] },
    specify: { 
      type: String,
      required: function() {
        return this.otherIncomeSource === 'Other';
      }
    }
  }
}, { timestamps: true });

export default mongoose.model('Gramsavalamban', GramsavalambanSchema);