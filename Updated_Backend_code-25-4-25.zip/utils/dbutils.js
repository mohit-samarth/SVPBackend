// Place this in a utility file like utils/dbUtils.js
import mongoose from 'mongoose';

export const removeUniqueIndex = async () => {
  try {
    await mongoose.connection.collection('acharyaKifDetails').dropIndex('svpId_1');
    console.log('Successfully removed unique index on svpId');
  } catch (err) {
    console.error('Error removing index:', err);
  }
};